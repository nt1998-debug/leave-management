const { createProxyMiddleware } = require('http-proxy-middleware');

module.exports = (req, res) => {
  // Cấu hình proxy
  const proxy = createProxyMiddleware({
    target: 'https://script.google.com',
    changeOrigin: true,
    pathRewrite: {
      '^/api': '/macros/s/AKfycbyd0HQnHTucW_QfiSutEmPQ0tH-gZJ3wm4VQSlh8Y3R/exec'
    },
    onProxyRes: function(proxyRes, req, res) {
      // Thêm CORS headers
      proxyRes.headers['Access-Control-Allow-Origin'] = '*';
      proxyRes.headers['Access-Control-Allow-Methods'] = 'GET,POST,OPTIONS';
      proxyRes.headers['Access-Control-Allow-Headers'] = 'Content-Type';
    }
  });
  
  return proxy(req, res);
};